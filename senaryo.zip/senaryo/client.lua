local texts = {}
local customFonts = {}

addEventHandler("onClientResourceStart", resourceRoot, function()
    customFonts["RobotoB"] = dxCreateFont("RobotoB.ttf", 14)
end)

addEvent("create3DText", true)
addEventHandler("create3DText", root,
    function(id, text, x, y, z, size, fontName, color, maxDistance)
        local fontToUse = customFonts[fontName] or fontName or "default-bold"

        texts[id] = {
            text = text,
            x = x,
            y = y,
            z = z,
            size = size or 1,
            font = fontToUse,
            color = color or tocolor(255, 255, 255, 255),
            maxDistance = maxDistance or 50
        }
    end
)

addEvent("delete3DText", true)
addEventHandler("delete3DText", root,
    function(id)
        texts[id] = nil
    end
)

addEventHandler("onClientRender", root, function()
    local px, py, pz = getElementPosition(localPlayer)

    for _, t in pairs(texts) do
        local dist = getDistanceBetweenPoints3D(t.x, t.y, t.z, px, py, pz)

        if dist <= t.maxDistance then
            local sx, sy = getScreenFromWorldPosition(t.x, t.y, t.z)
            if sx and sy then
                local r, g, b, a = getColorComponents(t.color)
                local r2, g2, b2 = applyDarknessByDistance({r, g, b}, dist)
                dxDrawText(t.text, sx, sy, sx, sy, tocolor(r2, g2, b2, a), t.size, t.font, "center", "center", false, false, false, true)
            end
        end
    end
end)

function getColorComponents(color)
    if type(color) == "number" then
        local r, g, b, a = getColorFromString(string.format("#%06X", color))
        return r or 255, g or 255, b or 255, a or 255
    end
    return 255, 255, 255, 255
end

function applyDarknessByDistance(color, distance)
    local factor = math.min(math.max((distance - 10) / 40, 0), 1)
    local r = math.floor(color[1] * (1 - factor))
    local g = math.floor(color[2] * (1 - factor))
    local b = math.floor(color[3] * (1 - factor))
    return r, g, b
end
