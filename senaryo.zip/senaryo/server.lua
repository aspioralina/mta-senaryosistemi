local scenarioID = 0

local validColors = {
    kirmizi = true, yesil = true, mavi = true,
    sari = true, beyaz = true, siyah = true,
    turuncu = true, mor = true, pembe = true
}

addCommandHandler("senaryo", function(player, cmd, ...)
    local args = {...}
    if #args < 5 then
        outputChatBox("#FF0000[Senaryo] #FFFFFFKullanım: /senaryo [metin] [boyut] [font] [renk] [uzaklık]", player, 255, 255, 255, true)
        return
    end

    local distance = tonumber(args[#args])
    local color = args[#args - 1]:lower()
    local font = args[#args - 2]
    local size = tonumber(args[#args - 3])
    local text = table.concat(args, " ", 1, #args - 4)

    -- Geçerli kontrol
    if not size or not distance then
        outputChatBox("#FF0000[Senaryo] #FFFFFFBoyut ve uzaklık sayısal olmalı.", player, 255, 255, 255, true)
        return
    end

    if distance < 10 or distance > 50 then
        outputChatBox("#FF0000[Senaryo] #FFFFFFUzaklık 10 ile 50 arasında olmalı.", player, 255, 255, 255, true)
        return
    end

    if not validColors[color] then
        outputChatBox("#FF0000[Senaryo] #FFFFFFGeçersiz renk ismi. (örn: kirmizi, yesil, beyaz)", player, 255, 255, 255, true)
        return
    end

    local x, y, z = getElementPosition(player)
    z = z + 0.5

    scenarioID = scenarioID + 1

    local nearbyPlayers = {}
    for _, plr in ipairs(getElementsByType("player")) do
        if getDistanceBetweenPoints3D(x, y, z, getElementPosition(plr)) <= distance + 10 then
            table.insert(nearbyPlayers, plr)
        end
    end

    triggerClientEvent(nearbyPlayers, "create3DText", resourceRoot, scenarioID, text, x, y, z, size, font, color)

    outputChatBox("#FF0000[Senaryo] #FFFFFF Senaryo oluşturuldu. ID: " .. scenarioID, player, 255, 255, 255, true)
end)

addCommandHandler("senaryosil", function(player, cmd, id)
    local numID = tonumber(id)
    if not numID then
        outputChatBox("#FF0000[Senaryo] #FFFFFFKullanım: /senaryosil [ID]", player, 255, 255, 255, true)
        return
    end

    local x, y, z = getElementPosition(player)
    local nearbyPlayers = {}
    for _, plr in ipairs(getElementsByType("player")) do
        if getDistanceBetweenPoints3D(x, y, z, getElementPosition(plr)) <= 60 then
            table.insert(nearbyPlayers, plr)
        end
    end

    triggerClientEvent(nearbyPlayers, "delete3DText", resourceRoot, numID)
    outputChatBox("#FF0000[Senaryo] #FFFFFF Senaryo #" .. numID .. " kaldırıldı.", player, 255, 255, 255, true)
end)
